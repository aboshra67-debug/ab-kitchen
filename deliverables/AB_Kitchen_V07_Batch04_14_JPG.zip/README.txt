AB Kitchen V0.7 batch 04; 14 JPEG images; AI-generated realistic illustrations.
All images named by recipe ID.
Original app source untouched.
