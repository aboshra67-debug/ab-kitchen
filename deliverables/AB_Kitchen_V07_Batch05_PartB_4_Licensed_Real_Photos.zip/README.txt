AB Kitchen V0.7. Four independent genuine Wikimedia Commons photographs with attribution and license information in attribution.json. No app source changes.
