AB Kitchen V0.7 - First 20 missing recipe visuals
This pack contains 20 standalone original AI-generated photorealistic JPEG food images.
Each filename is the exact recipe id in assets/data/recipes_ar.json.
No application source or existing assets are replaced in this batch.
See manifest.json for order, source type and license context.
