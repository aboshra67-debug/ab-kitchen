AB Kitchen v0.7: two independent realistic AI-generated JPEG food images. No code modified.
