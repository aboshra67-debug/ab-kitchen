# AB Kitchen — مطبخ العالم

**آخر إصدار: V0.6 (توسيع المطبخ المصري).** عدد الوصفات الآن **148 وصفة** من 8 مطابخ، منها **123 وصفة مصرية**، متضمنة 14 عائلة من كتالوج الحلويات المنزلية المستوحاة.

## قسم المطبخ المصري

- تمت إضافة **104 وصفات مصرية مميزة** دون حذف أو تعديل الوصفات الـ44 السابقة، تشمل الأطباق الرئيسية، الإفطار، الأكلات الشعبية، المحاشي، الطواجن والصواني، الأسماك والمأكولات البحرية، الشوربات، المقبلات والسلطات، المخبوزات والمعجنات، والحلويات التقليدية.
- اختيار مصر يعرض تصنيفاتها فقط، مع إعادة تصنيف الفلتر تلقائيًا عند تبديل البلد، وبطاقة دخول مباشرة للقسم المصري.
- الأسماء والمقادير والخطوات منزلية تقريبية وتحتاج تجربة مطبخية قبل نشر التطبيق للمستهلكين؛ أزمنة بعض الوصفات لا تشمل النقع المسبق.
- **الصور:** أصول الصور الـ31 القديمة محفوظة بالكامل؛ لا نعرض صور صنف آخر للمحتوى الذي لم يحصل بعد على صورته المطابقة. تظهر علامة توضيحية مؤقتة لهذا الصنف، لحد تجهيز تصوير أو صور أصلية بجودة مناسبة.
- لا تغيير في مفاتيح `SharedPreferences` أو بيانات التفضيلات والطبخ والمشتريات المخزنة؛ أرقام معرفات الوصفات القديمة محفوظة.
- CI: `flutter analyze` و`flutter test` ثم APK Debug وiOS Simulator. النجاح يعتمد على التشغيل الفعلي في GitHub وليس فحص JSON وحده.

نسخة أولية **V0.2.0** حقيقية من تطبيق Flutter واحد يعمل على Android وiOS، بعرض عربي RTL.

## الوظائف المنفذة

- استعراض 30 وصفة أولية أصلية الصياغة من 8 مطابخ (مصر، السعودية، سوريا، تركيا، إيطاليا، الهند، المغرب، لبنان).
- البحث حسب اسم الأكلة أو مكوّناتها، والتصفية حسب الدولة ونوع الأكلة والمفضلة.
- تفاصيل الوصفات، ضبط عدد الأشخاص، قائمة مقادير قابلة للتأشير، خطوات طبخ ومؤقت لكل خطوة، وقراءة عربية صوتية للخطوات عبر المحرك الصوتي الموجود على الجهاز (حسب توفره).
- «مطبخي»: مكونات الثلاجة المتوفرة واقتراح وصفات وفق نسبة المكونات المتطابقة.
- قائمة مشتريات بتجميع الكميات المتطابقة، وإضافة العناصر يدويًا وشطب المشتريات.
- جدول أسبوعي للإفطار والغداء والعشاء، وإضافة مقادير خطة الأسبوع لقائمة المشتريات.
- مساعد طبخ **محلي قائم على قواعد واضحة** لاقتراح وصفات ونصائح عامة وبدائل أولية. ليس متصلاً بخدمة ذكاء اصطناعي ولا يدعي ذلك.
- مفضلة، وضع داكن، عدد أفراد افتراضي، حفظ محلي للبيانات مع تأكيد قبل المسح.
- قاعدة وصفات JSON منفصلة قابلة للتوسعة، ووظائف منطق الأعمال في `KitchenController`.

## حدود الإصدار

- 30 وصفة نموذجية؛ ليس بعد مكتبة كاملة لجميع أكلات العالم. المقادير تحتاج تحريرًا ومراجعة طهوية متخصصة قبل طرح قاعدة واسعة.
- الوصفات تستخدم رموزًا تعبيرية بدل صور تصوير احترافية محمية الحقوق.
- لا يوجد تسجيل حساب ولا مزامنة سحابية ولا إشعارات نظام ولا نصائح تغذية طبية ولا ملفات صوتية مسجلة أو ذكاء اصطناعي متصل. ميزة قراءة الخطوات تستخدم TTS الخاص بالجهاز.
- لا يوجد دعم إنجليزي حتى الآن، رغم جاهزية بنية المحتوى للإضافة.
- لا توجد مفاتيح توقيع أو أسرار داخل المشروع.

## تحديث V0.2

- تحديث مؤقت الطبخ ليعتمد على توقيت الانتهاء الفعلي، مع إعادة حسابه بعد الرجوع للتطبيق.
- تسريع إضافة مكوّنات الوصفة إلى المشتريات بحفظ مجمّع مرة واحدة.
- منع إدخال كميات لا نهائية وغير صحيحة وإضافة اختبارات وظائف وموديولات رئيسية.
- شاشة خطوات قابلة للتمرير على الأجهزة الصغيرة.
- يحتوي الملف `V0_2_SAFE_PATCH.md` على كشف الملفات المعدلة، و`CI_BUILD_INSTRUCTIONS.md` على خطوات البناء دون الادعاء أنه تم.

## التثبيت المحلي

المتطلبات: Flutter stable، Android Studio/SDK لبناء Android؛ Mac وXcode لبناء iOS.

```bash
flutter create --project-name ab_kitchen --org com.absoftware --platforms=android,ios .
flutter pub get
flutter analyze
flutter test
flutter run
flutter build apk --debug
# على macOS وXcode:
flutter build ios --simulator --debug
```

> إضافة ملفات Android/iOS عبر `flutter create` أمر مقصود لإتاحة أحدث قوالب Flutter الرسمية دون نسخ قوالب قديمة أو ملفات تعريفات توقيع إلى السورس. سير عمل GitHub Actions ينفّذ هذا تلقائيًا قبل البناء.

## إصدار متجر حقيقي

- Android: يحتاج تثبيت package name نهائي، ملف keystore خاص بالمستخدم محفوظ خارج المستودع، AAB بتوقيع إنتاجي، محتوى وحقوق صور وسياسة خصوصية واختبار أجهزة.
- iOS: يحتاج macOS + Xcode وحساب Apple Developer وتوقيع شهادة ونظام provisioning، ثم أرشفة وتوزيع TestFlight/App Store.
- ملف `app-debug.apk` من CI **للتجربة فقط** وليس APK إنتاجيًا موقعًا بمفتاح خاص ثابت.

## الأمان

- لا يوجد أي طلب شبكي أو جمع بيانات في الإصدار الحالي.
- المساعد الحالي لا يرسل مدخلات المستخدم لأي خدمة خارجية.
- إذا تلف JSON التخزين المحلي، لا يتم استبداله تلقائيًا أثناء الاستخدام؛ يظهر تحذير للمستخدم.
- لا تضع API keys في تطبيق الموبايل مستقبلًا؛ يتم ربط مقدم AI عبر Backend آمن.

## ملفات مهمة

- `lib/main.dart`: تهيئة التطبيق وواجهات التنقل والثيم.
- `lib/core/kitchen_controller.dart`: الحالة والبيانات المحلية.
- `lib/core/assistant_service.dart`: واجهة مساعد قابلة للاستبدال.
- `assets/data/recipes_ar.json`: بيانات الوصفات (يمكن تدقيقها دون تعديل كود).
- `test/recipe_test.dart`: اختبارات تحقق أولية.
- `.github/workflows/flutter_ci.yml`: اختبار وبناء Android/iOS غير موقعين للإنتاج.

## حالة التحقق والتسليم

فُحصت قاعدة JSON وبنية الملفات وصحة ZIP؛ **لم يجر Flutter analyze أو Flutter test أو بناء APK/IPA** لأن البيئة لا تحتوي Flutter SDK أو Android SDK أو Xcode ولا يمكن تنزيلها من الشبكة هنا. لم يُرفع المشروع بعد إلى مستودع AB Kitchen مستقل. نتيجة GitHub Actions ليست معروفة قبل تشغيله.


## V0.3 warm identity

The approved red/orange AB Kitchen logo is bundled in `assets/branding/ab_kitchen_logo.jpg`. Screens share a reusable warm brand system; no recipe or storage changes. Remote-media permanent offline downloads and selectable color themes are planned later.


## V0.5 Egyptian-inspired dessert catalogue (safe add-on)
- 14 **base dessert families** in `assets/data/recipes_ar.json`; existing 30 recipes untouched.
- 9 shared optional toppings in `lib/core/dessert_toppings.dart`; variants are **not** separate recipes.
- Selected toppings persist alongside pre-existing preferences (same v1 key). The shopping list and cooking instructions include selected additions and scale with serving count.
- The app offers original, AI-generated, realistic-looking **illustrative photos** for each base dessert and works offline; no restaurant photography or trademark is used inside the assets.
- Dessert names are domestic interpretations *inspired by publicly described menu concepts*, not an affiliated product or a claimed confidential recipe. Some experimental menu names have speculative home reconstructions clearly labeled as such.
- Tests: `flutter analyze`, `flutter test`, Android debug build, unsigned iOS simulator build in GitHub Actions. This repository does not contain an iOS-signing certificate.