package com.absoftware.ab_kitchen

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
