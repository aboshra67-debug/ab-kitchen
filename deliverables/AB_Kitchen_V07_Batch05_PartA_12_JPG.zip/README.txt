AB Kitchen V0.7 batch 05 part A: 12 independent generated JPEG food images.
PDF catalog delivered separately. 22 recipe pictures remain. The main app was not modified.
